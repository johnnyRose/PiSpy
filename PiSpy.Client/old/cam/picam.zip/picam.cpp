#include <stdio.h>
#include <unistd.h>
#include "camera.h"

void CameraCallback(CCamera* cam, const void* buffer, int buffer_length)
{
	printf("Do stuff with %d bytes of data\n",buffer_length);
}

int main(int argc, const char **argv)
{
	printf("PI Cam api tester\n");
	StartCamera(1280,720,30,CameraCallback);
	sleep(10);
	StopCamera();
}
